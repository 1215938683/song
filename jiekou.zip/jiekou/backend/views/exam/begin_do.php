<center><?=$data[0]['title']?></center>
<!-- 单选一 -->
<form action="index.php?r=exam/login" method="post">
	<?php
	for($i=0;$i<=19;$i++){
	?>
	<!-- 单选 -->
		<?php if($data[$i]['type'] == '1-单选'){?>
			<span><?=$data[$i]['type']?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>(<?=$data[$i]['num']?>分)</span><br>
			<span><?=$data[$i]['stem']?></span>

			<?php for($j='A';$j<='D';$j++){?>
					<div class="radio">
					<label>
					<input type="radio" value="<?=$j?>"  name="<?=$data[$i]['t_id']?>"><?=$j?>:<?=$data[$i][$j]?>
					</label>
					</div>
			<?php }?>
		<?php }?>
	<!-- 多选 -->
		<?php if($data[$i]['type'] == '2-多选'){?>
			<span><?=$data[$i]['type']?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>(<?=$data[$i]['num']?>分)</span><br>
			<span><?=$data[$i]['stem']?></span>
			<?php for($j='A';$j<='D';$j++){?>
					<div class="checkbox">
					<label><input type="checkbox" value="<?=$j?>"  name="<?=$data[$i]['t_id']?>[]"> <?=$j?>:<?=$data[$i][$j]?></label>
					</div>
			<?php }?>

		<?php }?>
	<!-- 判断 -->
	<?php if($data[$i]['type'] == '0-判断'){?>
			<span><?=$data[$i]['type']?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>(<?=$data[$i]['num']?>分)</span><br>
			<span><?=$data[$i]['stem']?></span>

			<?php for($j='A';$j<='B';$j++){?>
					<div class="radio">
					<label>
					<input type="radio"  value="<?=$j?>" name="<?=$data[$i]['t_id']?>"><?=$j?>:<?=$data[$i][$j]?>
					</label>
					</div>
			<?php }?>
		<?php }?>

	<?php
	}
	?>
		<button type="submit" class="btn btn-danger" class="button">提交</button>
	</form>
	