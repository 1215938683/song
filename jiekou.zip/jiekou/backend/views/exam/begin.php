<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Bootstrap 实例 - 选择框</title>
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">  
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<form role="form" action="index.php?r=exam/begin_do" method="post">
	<div class="form-group">
		<label for="name">选择列表</label>
		<select class="form-control" name="name[]">
			<option value="第一单元">第一单元</option>
			<option value="第二单元">第二单元</option>
			<option value="第三单元">第三单元</option>
			<option value="第四单元">第四单元</option>
			<option value="第五单元">第五单元</option>
			<option value="第六单元">第六单元</option>
			<option value="第七单元">第七单元</option>
			<option value="第八单元">第八单元</option>
			<option value="第九单元">第九单元</option>
			<option value="第十单元">第十单元</option>
			<option value="第十一单元">第十一单元</option>
			<option value="第十二单元">第十二单元</option>
			<option value="第十三单元">第十三单元</option>
			<option value="第十四单元">第十四单元</option>
			<option value="第十五单元">第十五单元</option>
			<option value="第十六单元">第十六单元</option>
			<option value="第十七单元">第十七单元</option>
			<option value="第十八单元">第十八单元</option>
			<option value="第十九单元">第十九单元</option>
			<option value="第二十单元">第二十单元</option>
		</select>
	</div>
	<button type="submit" class="btn btn-danger">开始答题</button>
</form>

</body>
</html>
