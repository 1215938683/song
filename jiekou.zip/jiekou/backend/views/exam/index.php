
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
	<title>Bootstrap 实例 - 基本表单</title>
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<style type="text/css">
		.div{
			display: flex;
			margin-left: 1000px;
		}
		.a{
			color: white;
		}
	</style>
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	 <script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.staticfile.org/popper.js/1.12.5/umd/popper.min.js"></script>
  <script src="https://cdn.staticfile.org/twitter-bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>

<body>
<nav class="breadcrumb">
  <span class="breadcrumb-item active">试题管理</span>
  <a class="breadcrumb-item" href="index.php?r=exam/show">试题列表</a>
</nav>
<div class="div">
		<button type="button" class="btn btn-danger" class="button"><a href="index.php?r=exam/show" class="a">试题列表</a></button>
	</div>
<form role="form" method="post" action="index.php?r=exam/add" enctype="multipart/form-data">
	<div class="form-group">
		<label for="name">单元名称</label>
		<input type="text" class="form-control" id="name" 
			   placeholder="请输入名称" name="title">
	</div>
	<div class="form-group">
		<label for="inputfile">文件输入</label>
		<input type="file" id="inputfile" name="excel">
		
	</div>
	<button type="submit" class="btn btn-default">提交</button>
</form>
	
</body>
</html>