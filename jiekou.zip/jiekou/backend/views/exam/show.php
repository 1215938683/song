<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
	<title>Bootstrap 实例 - 悬停表格</title>
	<style type="text/css">
		.div{
			display: flex;
			margin-left: 1000px;
		}
		.a{
			color: white;
		}
		.div1{
			display: flex;
			margin-left: 900px;
			margin-top: -33px;
		}
	</style>
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">  
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
  <script src="https://cdn.staticfile.org/popper.js/1.12.5/umd/popper.min.js"></script>
  <script src="https://cdn.staticfile.org/twitter-bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<nav class="breadcrumb">
   <span class="breadcrumb-item active">试题列表</span>
  <a class="breadcrumb-item" href="index.php?r=exam/index">试题管理</a>
 
</nav>
<body>
	<div class="div">
		<button type="button" class="btn btn-danger" class="button"><a href="index.php?r=exam/index" class="a">添加试题</a></button>
	</div>
	<div class="div1">
		<button type="button" class="btn btn-danger" class="button"><a href="index.php?r=exam/begin" class="a">选择题库</a></button>
	</div>

<table class="table table-hover">
	<caption>试题列表</caption>
	<thead>
		<tr>
			<th>ID</th>
			<th>单元</th>
			<th>类型</th>
			<th>题干</th>
			<th>选项A</th>
			<th>选项B</th>
			<th>选项C</th>
			<th>选项D</th>
			<th>选项E</th>
			<th>选项F</th>
			<th>出题人</th>
		</tr>
	</thead>
	<?php
	foreach($data as $v){
	?>
	<tbody>
		<tr>
			<td><?php echo $v['t_id'];?></td>
			<td><?php echo $v['title']?></td>
			<td><?php echo $v['type']?></td>
			<td><?php echo $v['stem']?></td>
			<td><?php echo $v['A']?></td>
			<td><?php echo $v['B']?></td>
			<td><?php echo $v['C']?></td>
			<td><?php echo $v['D']?></td>
			<td><?php echo $v['E']?></td>
			<td><?php echo $v['F']?></td>
			<td><?php echo $v['name']?></td>
		</tr>
	</tbody>
<?php  }?>
</table>


</body>
</html>
