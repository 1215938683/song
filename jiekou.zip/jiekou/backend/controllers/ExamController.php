<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use common\libs\curl;
header("content-type:text/html;charset=utf-8");
class ExamController extends Controller
{
	public $enableCsrfValidation = false;
	public function actionIndex(){
		return $this->render('index');
	}
	public function actionAdd(){

		require(__DIR__ . '/../../common/libs/PHPExcel.php');
		

		$excel = new \PHPExcel();
		// var_dump($excel);exit;
		if(Yii::$app->request->isPost){
			$dir = '/phpstudy/www/jiekou/backend/upload/excel.xls';
			$reg = move_uploaded_file($_FILES['excel']['tmp_name'],$dir);
			// var_dump($reg);exit;
			if($reg){
				$url = "http://www.munan.net.cn/jiekou/api/web/index.php?r=exam/import";
				$param['title'] = Yii::$app->request->post('title');
				// var_dump($param);exit;
				$file['excel'] = $dir;
				$reg = curl::_post($url,$param,$file);
				if($reg){
					echo $reg;exit;
				}
			}
			
		}else{
			return $this->render('add');
		}
	}
	public function actionShow(){
		$sql = "select * from topic limit 20";
		$data = Yii::$app->db->createCommand($sql)->queryAll();
		return $this->render('show',['data'=>$data]);
	}
	public function actionBegin(){
		return $this->render('begin');
	}
	public function actionBegin_do(){
		$name = Yii::$app->request->post('name');
		// var_dump($name);die;
		$name = $name['0'];
		$sql = "select * from topic where title = '$name'";
		$data = Yii::$app->db->createCommand($sql)->queryAll();
		// $data = $data[0];
		// var_dump($data);exit;
		if(!$data){
			echo "<script>alert('对不起，没有此单元，请先添加');</script>";
			return $this->render('index');
		}
			return $this->render('begin_do',['data'=>$data]);
		}
	public function actionLogin(){
			$danxuan = Yii::$app->request->post();
			var_dump($danxuan);die;
		}
		// var_dump($data);exit;
	
}