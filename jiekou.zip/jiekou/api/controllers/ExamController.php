<?php
namespace api\controllers;

use Yii;
use yii\web\Controller;
/**
 * Site controller
 */
class ExamController extends Controller
{
	public $enableCsrfValidation = false;
	public function actionImport(){
		header("content-type:text/html;charset=utf-8");
		$title = Yii::$app->request->post('title');
		$dir = '/phpstudy/www/jiekou/api/upload/excel.xls';
		$reg = move_uploaded_file($_FILES['excel']['tmp_name'],$dir);
		// $title = Yii::$app->request->post('title');
		require(__DIR__ . '/../../common/libs/PHPExcel.php');

		$objPHPExcel = \PHPExcel_IOFactory::load($dir);
		$sheetData = $objPHPExcel->getActiveSheet(0)->toArray(null,true,true,true);
		// var_dump($sheetData);exit;
		unset($sheetData[1]);
		foreach($sheetData as $k=>$v){
			var_dump($v);
			$point = $v['A'];
			$type = $v['B'];
			$stem = $v['C'];
			$A = $v['D'];
			$B = $v['E'];
			$C = $v['F'];
			$D = $v['G'];
			$E = $v['H'];
			$F = $v['I'];
			$answer = $v['J'];
			$name = $v['L'];
			$time = time();
			if($type == '1-单选'){
				$num = '5';
			}else if($type =='2-多选'){
				$num = '3';
			}else{
				$num = '2';
			}
			$sql = "insert into topic values('','$title','$type','$stem','$A','$B','$C','$D','$E','$F','$name','$time','$num')";
			$data = Yii::$app->db->createCommand($sql)->execute();
			$sql1 = "insert into answer values('','$answer','')";
			$data1 = Yii::$app->db->createCommand($sql1)->execute();
		}
		echo "ok";
		
	}

}